// All imports in this file will be compiled into vendors.js file.
//
// Note: ES6 support for these imports is not supported in base build

module.exports = [
  './node_modules/jquery/dist/jquery.js',
  './node_modules/bootstrap-sass/assets/javascripts/bootstrap.min.js',
  './node_modules/jcf/js/jcf.js',
  './node_modules/jcf/js/jcf.select.js',
  './node_modules/jcf/js/jcf.radio.js',
  './node_modules/jcf/js/jcf.checkbox.js',
  './node_modules/@fengyuanchen/datepicker/dist/datepicker.js',
];
